---
templateKey: work-page
pagetype:
  - page
title: Spettacoli
date: 2023-03-02T10:17:05.133Z
thumbnail: /img/lab01.jpeg
number: 2
featuredimage: /img/lab01.jpeg
locale: "it"
translationKey: "performances-page"
---


